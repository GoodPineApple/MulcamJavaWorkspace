
public class Exam05 {

	public static void main(String[] args) {
		int a = 0;
		for (int b = 0; b <= 500; b++) {
			a = a + b;
		}
		System.out.println(a);

	}

}
