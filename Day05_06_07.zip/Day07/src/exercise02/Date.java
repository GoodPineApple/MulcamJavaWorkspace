package exercise02;

public class Date {
	int year;
	int month;
	int day;
	
	void setday(){
		
	}
	
	
	

}
