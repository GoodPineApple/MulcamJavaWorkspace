package programmin01;

import java.util.Scanner;

public class Pro03 {

	public static void main(String[] args) {
		Scanner Input = new Scanner(System.in);
		
		System.out.print("���ڿ��� �Է��Ͻÿ�. ");
		String s = Input.nextLine();
		
		
		
		// TODO Auto-generated method stub

	}

}
