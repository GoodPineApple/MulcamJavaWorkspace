package exercise03;

class Rectangle {
	int width, height;
	int area() {
		return width * height;
	}

}
