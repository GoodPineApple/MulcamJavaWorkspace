package exercise01;

public class NumberBox {
	public int ivalue;
	public float fvalue;

}
