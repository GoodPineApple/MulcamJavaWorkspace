package exercise01;

public class Tesst {

	public static void main(String[] args) {
		NumberBox a = new NumberBox();
		a.ivalue = 10;
		
		a.fvalue = (float)1.2345;
		
		System.out.println(a.fvalue +", "+a.ivalue);
		
	}

}
