package dafault;
public class Programming08 {
	public static void main(String[] args) {

		for (int a = 1; a <= 10; a++) {

			for (int i = 1; i <= 10; i++) {
				System.out.print(a*i + " \t");
			}

			System.out.print('\n');
		}
	}

}
