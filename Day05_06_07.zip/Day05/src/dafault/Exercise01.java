//
// 1) 1. int count;
//       if(count>=20 && count<60)
//          count++
//    2. if(x > y)
//          int max = x; int min = y
//       if(x < y)
//          int max = y; int min = x
//    3. if(x >= 1 && x <= 20)
//          y = x
//    4. for(int i = 0; i>0; i++);
//    5. while(true){
//          i++
//          }
// 
// 2) 1. ��°�� : 1�� �׷� else�� �鿩�����
//     2. ��°�� : 2�� �׷� else�� �鿩�����
//    
// 3) 1. if(0 < age && age < 18)
//    2. if(x == 0)
//    3. grade�� ���� ������ �ȵǾ �ƹ��ϵ� �Ͼ�� �ʴ´�.
//       case 3.0�� ���� �������־�� ��
//       
// 4) 1. i=0
//       i=3
//       i=6
//       i=9
//    2. *
//       *
//       *
//       *
//       *
//       *
//       *
//       *
//       *
//
//    4. i=1
//		 i=2
//		 i=4
//		 i=5
//		 i=7
// 
// 6) 1. third
//    2. public class Exercise01 {
//            public static void main(String[] args) {
//                  int x = 3;
//                  if(x >= 0)
//                     if ( x == 0 )
//                         System.out.println("first") ;
//                     else System.out.println("second");
//                     System.out.pringln("third");
//             }
//       }
//    3. if(x >= 0) {
//            if ( x == 0 ) { 
//                System.out.println("first") ;
//            }
//            else System.out.println("second");
//       System.out.pringln("third");
//       }  
