package dafault;
public class Test09 {
	public static void main(String[] args) {

		for(int i = 10; i > 0; i=i-2) {
			System.out.println("student:" + i);
		}

	}

}
