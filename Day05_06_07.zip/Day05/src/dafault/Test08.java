package dafault;
public class Test08 {
	public static void main(String[] args) {

		for(int i = 1; i <5; i++) {
			System.out.print(2*i + " ");
		}

	}

}
