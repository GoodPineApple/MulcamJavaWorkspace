package dafault;
public class Test10 {
	public static void main(String[] args) {

		for(int i = 1; i < 6; i++) {
			for(int j=5; j>=1; j--) {
				System.out.println(i + "���ϱ�" + j + "��" + i*j);	
			}
		}

	}

}
