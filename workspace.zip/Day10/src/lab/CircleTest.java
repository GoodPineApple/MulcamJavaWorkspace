package lab;

public class CircleTest {

	public static void main(String[] args) {
		
		Circle myCircle = new Circle(5.0);
		System.out.println(myCircle.getArea());
		System.out.println(myCircle.getPerimeter());
	}

}
