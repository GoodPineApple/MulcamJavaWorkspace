package programming05;

public class BankAccount {
	String name;
	String accountNumber;
	int balance;
	double interest;
	
	public BankAccount() {
		
	}
	
	public BankAccount(String name, String accountNumber, int balance, double interest) {
		
	}
	
	

}
