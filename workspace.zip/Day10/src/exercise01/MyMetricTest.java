package exercise01;

public class MyMetricTest {

	public static void main(String[] args) {
		MyMetric mine = new MyMetric();
		System.out.println(mine.kilotoMile(10));
		System.out.println(mine.miletoKilo(10));
		

	}

}
