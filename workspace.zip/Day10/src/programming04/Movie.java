package programming04;

public class Movie {
	String title;
	String director;
	String company;
	

	public Movie() {
		
	}
	public Movie(String title, String director, String company) {
		this.title = title;
		this.director = director;
		this.company = company;
	}
	
	

}
