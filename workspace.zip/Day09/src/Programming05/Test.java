package Programming05;

public class Test {
	public static void main(String[] args) {
		Employee gangnam = new Employee();
		gangnam.setEmployee("���¹�", "0109545971", 9000);
		System.out.println(gangnam);
		
		
	}

	

}
