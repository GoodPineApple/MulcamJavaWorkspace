package test03;

public class Test {

	public static void main(String[] args) {
		DiceGame gameMachine = new DiceGame();
		gameMachine.startGame();
		
	}

}
