package exercise01;

public class Movie {
	private String title, director, actor;
	
	void setTitle(String s) {
		title = s;
	}
	String getTitle(){
		return title;
	}
	
	void setDirector(String s) {
		director = s;
	}
	String getDirector(){
		return director;
	}
	
	void setActor(String s) {
		actor = s;
	}
	String getActor(){
		return actor;
	}
}