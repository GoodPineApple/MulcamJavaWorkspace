package exercise01;

public class MovieTest {

	public static void main(String[] args) {

		Movie M = new Movie();

		M.setTitle("Transformer");

	}

}
