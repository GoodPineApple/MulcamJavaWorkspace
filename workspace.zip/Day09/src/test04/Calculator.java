package test04;

public class Calculator {
	
	public int square(int num) {
		int result = num*num;
		return result;
	}
	
	public double square(double num) {
		double result = num*num;
		return result;
	}
}
