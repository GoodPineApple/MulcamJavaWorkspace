package test04;

public class Test {

	public static void main(String[] args) {
		Calculator ca1 = new Calculator();
		System.out.println(ca1.square(1.5));	
		

		String s = new String("hello Java");
		
	}
	

}
