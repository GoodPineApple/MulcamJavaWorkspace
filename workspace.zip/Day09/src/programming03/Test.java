package programming03;

public class Test {

	public static void main(String[] args) {
		Dice myDice = new Dice();
		myDice.rollDice();
		myDice.resultDice();
	}

}
