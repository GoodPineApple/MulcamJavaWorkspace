package Programming04;

public class Test {

	public static void main(String[] args) {
		Point myPoint = new Point();
		
		myPoint.setPoint(1056.1, -354.0587);
		myPoint.printPoint();
		
	}

}
