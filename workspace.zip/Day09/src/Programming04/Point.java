package Programming04;

public class Point {
	
	double x, y;
	
	public void setPoint(double user_x, double user_y) {
		x = user_x;
		y = user_y;
	}
	
	void printPoint() {
		System.out.println("x��:" + x + " y��:" + y);
	}
	

}
