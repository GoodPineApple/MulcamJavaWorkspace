package midtest;

import java.util.Scanner;

public class test02 {

	public static void main(String[] args) {
		Scanner Input = new Scanner(System.in);

		System.out.print("�迭�� ũ�⸦ �Է��Ͻÿ� :");
		int size = Input.nextInt();
		double[] num = new double[size];
	}
}
