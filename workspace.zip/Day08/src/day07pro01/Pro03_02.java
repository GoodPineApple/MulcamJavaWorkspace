package day07pro01;

public class Pro03_02 {
	public static void main(String[] args) {
		String s = "Hello hi bye";
		
		for(int i = 0; i<s.length(); i++) {
			System.out.println(s.charAt(i));
		}
	}

}
